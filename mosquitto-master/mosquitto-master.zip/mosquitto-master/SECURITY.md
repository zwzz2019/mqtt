# Security Policy

## Reporting a Vulnerability

If you think you have found a security vulnerability in Mosquitto, please follow the steps on [Eclipse Security](https://www.eclipse.org/security/) page to report it.
